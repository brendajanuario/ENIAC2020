import requests
import bs4
from bs4 import BeautifulSoup
import time
import datetime
from datetime import date, timedelta
from urllib.request import urlopen
from urllib.error import HTTPError
from urllib.error import URLError
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def save_news_FolhaSP(url):
    textualContent = ""    
    try:
        html = urlopen(url)
        
    except HTTPError as e:
        print(e)
        
    except URLError:
        print("Server down or incorrect domain")
        
    else:
        soup = BeautifulSoup(html.read(), "html5lib")
        news_href = soup.find("div",{"class": "c-headline__content"}) 
        href = news_href.find('a')
        
        try:
            html = urlopen(href.get('href'))   #Tenta acessar o link da notícia, caso exista
            soup = BeautifulSoup(html.read(), "html5lib")
            
            foundTitle = soup.find("h2", {"class":"c-headline__title"}) #acessa o título da notícia
            title = foundTitle.getText().strip()
            
            foundDate = soup.find(class_= "c-headline__dateline") #acessa a data da notícia
            data = foundDate.getText().strip()
            
            news_body = soup.find("div", {"class": "c-news__body"}) #acessa os parágrafos da notícia
            paragraphs = news_body.find_all('p')
            
            for paragraph in paragraphs:
                textualContent = textualContent+("\n") + paragraph.getText().replace('\n', '')

            try:
                with open("Notícias Folha de São Paulo/"+"noticias folha de sp"+".txt", "a", encoding="utf-8") as file:
#                    file.write ("Classificação do título:\nClassificação da Notícia:\n\n")
                    file.write (title+"\n"+data+"\n\n")
    
                print("Notícia salva!\n\n")
            except:
                print("Não foi possível salvar a notícia "+title+' do site Folha de São Paulo.\n')


        except:
            print("Não há notícias registradas.\n")
                      
def save_news_G1(url):
    
    try:
        html = urlopen(url)
    except HTTPError as e:
        print(e)
    except URLError:
        print("Server down or incorrect domain")
    else:  
        sopa = BeautifulSoup(html.read(), "html5lib")
        noticias = sopa.find_all("div",{"class": "widget--info__text-container"})
        for noticias in noticias:
            title = (noticias.find("div",{"class":"widget--info__title product-color "}).text.strip())
            datePublished = (noticias.find("div",{"class":"widget--info__meta"}).text)        

            with open("Notícias Globo/"+"Notícias G1"+".txt", "a", encoding="utf-8") as file: #salva o conteúdo da notícia em um .txt
                            file.write (title+"\n"+datePublished+"\n\n")
#    textualContent = ""
#    try:
#        res = requests.get(url)
#        res.raise_for_status()
#        soup = bs4.BeautifulSoup(res.text, "html.parser")
#        print("até aq td bem 1")
#    except HTTPError as e:
#        print(e)
#        
#    except URLError:
#        print("Server down or incorrect domain")
#    else:
#        try:
#            news_href = soup.find_all(a) #acessa o título da notícia
#        except:
#            print("Não tem notícias cadastradas.\n")    
#        else:
#            for el in news_href:
#                print(el.find('href'))
        
            
            
#            
#        title = soup.find('h1', {'class':'content-head__title'}).text #encontra título da notícia
#        datePublished = soup.find('time').text #encontra data de publicação da notícia
#            
#        paragraphs  = soup.find_all('p', {'class': 'content-text__container'}) #retorna o conteúdo texutal da notícia            
#        for paragraph in paragraphs:
#            textualContent = textualContent+("\n") + paragraph.getText().replace('\n', '')
#            
#        chrome.quit() #fecha o sita
#    
#        try:
#            with open("Notícias Globo/"+"Notícias G1"+".txt", "a", encoding="utf-8") as file: #salva o conteúdo da notícia em um .txt
##                file.write ("Classificação do título:\nClassificação da Notícia:\n\n")
#                file.write (title+"\n"+datePublished+"\n\n")
#    
#            print("Notícia salva!\n\n")
#        except:
#            print("Não foi possível salvar a notícia "+title+' do site G1.\n')
#    except HTTPError as e:
#        print(e)
#        
#    except URLError:
#        print("Server down or incorrect domain")


def save_news_Estadao(url):
    textualContent = ""
    try:
        res = requests.get(url)
        res.raise_for_status()
        soup = bs4.BeautifulSoup(res.text, "html.parser")
     
    except HTTPError as e:
        print(e)
        
    except URLError:
        print("Server down or incorrect domain")
    else:
        try:
            news_href = soup.find_all("section", {'class':'col-md-6 col-sm-6 col-xs-12 col-margin'}) #acessa o título da notícia
        except:
            print("Não tem notícias cadastradas.\n")    
        else:
            for el in news_href:
                link = el.find('a').get('href')           
                try: 
                    chrome_options = Options()
                    chrome_options.add_experimental_option( "prefs",{'profile.managed_default_content_settings.javascript': 2})#desativa JavaScript
                    chrome = webdriver.Chrome('chromedriver',chrome_options=chrome_options)
                    chrome.get(link)
                except HTTPError as e:
                    print(e)
        
                except URLError:
                    print("Server down or incorrect domain")
                    
                soup = BeautifulSoup(chrome.page_source,"lxml")
                
                foundTitle = soup.find("h1", {"class":"n--noticia__title"}) #acessa o título da notícia
                title = foundTitle.text

                foundDate = soup.find('div',{'class':'n--noticia__state'}) #acessa a data da notícia
                data = foundDate.find('p').getText().strip()
                
                paragraph = soup.find('div',{'class':'n--noticia__content content'}) #acessa o conteúdo da notícia
                textualContent  = paragraph.text   
                
                chrome.quit()

                try:
                    with open("Notícias Estadão/"+"Notícias Estadão"+".txt", "a", encoding="utf-8") as file:
#                        file.write ("Classificação do título:\nClassificação da Notícia:\n\n")
                        file.write (title+"\n"+data+"\n\n")
        
                    print("Notícia salva!\n\n")
                except:
                    print("Não foi possível salvar a notícia "+title+' do site Estadão.\n')
            

def acess_FolhaSP():
    q='bovespa'.upper()
    startDate = datetime.date(2019,1,1) 
    while startDate < datetime.date.today():    
        try:
            endDate = startDate + timedelta(1)   #### ONTEM!!! ####
        
            startDateSTR = str(startDate.strftime("%d-%m-%Y")).replace('-','%2F')
            endDateSTR =   str(startDate.strftime("%d-%m-%Y")).replace('-','%2F')
        
            url = 'http://search.folha.uol.com.br/search?q='+q+'&periodo=personalizado&sd='+startDateSTR+'&ed='+endDateSTR+'&site=todos'
                
            print('[Acessing] '+ url)
            print("data: ",endDate)
            save_news_FolhaSP(url)
    
            startDate = endDate
        except:
            print(str(datetime.datetime.now())+'[Erro] 30 segundos...')
            time.sleep(1)   


  
def acess_G1(): 
    q='ibovespa'.upper()
    startDate = datetime.date(2019,1,1)
    endDate = datetime.date(2019,3,31)
    while startDate <= endDate:    
        try:
            dateSTR = str(startDate.strftime("%Y-%m-%d"))
#            endDateSTR =   str(startDate.strftime("%d-%m-%Y")).replace('-','%2F')
#            print("Data autal:",startDate)
        
            url = 'https://g1.globo.com/busca/?q='+q+'&order=recent&from='+dateSTR+'T00%3A00%3A00-0200&to='+dateSTR+'T23%3A59%3A59-0200'
            url = url.encode('ascii', 'ignore').decode('ascii')
            
            print('[Acessing] '+ url)
            print("data: ",startDate)
            save_news_G1(str(url))

        except:
            print(str(datetime.datetime.now())+'[Erro] 30 segundos...')
            time.sleep(3)   
        startDate = startDate + timedelta(days=1)

def acess_Estadao():
    q='ibovespa'.upper()
    startDate = datetime.date(2019,1,1)
    finalDate = datetime.date(2019,3,31)
    while startDate < finalDate:    
        try:
            endDate = startDate + timedelta(1)   #### ONTEM!!! ####
        
            startDateSTR = str(startDate.strftime("%d-%m-%Y")).replace('-','%2F')
            endDateSTR =   str(startDate.strftime("%d-%m-%Y")).replace('-','%2F')
            
            url = 'https://busca.estadao.com.br/?tipo_conteudo=Not%C3%ADcias&quando='+startDateSTR+'-'+endDateSTR+'&q='+q+'&editoria%5B%5D=Economia&editoria%5B%5D=Pol%C3%ADtica&editoria%5B%5D=Opini%C3%A3o'
                    
            print('[Acessing] '+ url)
            print("data: ",endDate)
            save_news_Estadao(url)
    
            startDate = endDate
        except:
            print(str(datetime.datetime.now())+'[Erro] 30 segundos...')
            time.sleep(1) 

acess_Estadao()
#acess_G1()
#acess_FolhaSP()
